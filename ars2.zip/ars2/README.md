#
#
# UI.py, agent.py, object.pt and vector.py was done by Lucas,
# Motion model and Sensor model was done by Tom,
# Collision_detectiony.py was done by Margarita
#
# To run the code, simply run with python3 UI.py
# Sensor model requires shapely library to be installed
